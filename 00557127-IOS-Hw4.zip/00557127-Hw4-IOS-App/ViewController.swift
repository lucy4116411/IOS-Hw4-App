//
//  ViewController.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/12.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

