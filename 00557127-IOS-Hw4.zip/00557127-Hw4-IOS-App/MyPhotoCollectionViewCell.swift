//
//  MyPhotoCollectionViewCell.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/19.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit

class MyPhotoCollectionViewCell: UICollectionViewCell {
    var cellimage:UIImageView?
    
    override init(frame: CGRect){
        super.init(frame:frame)
        let width = (UIScreen.main.bounds.size.width)
        
        cellimage = UIImageView(frame: CGRect(x: 0, y: 0, width: width/3-30.0, height: width/3-30.0))
        
        self.addSubview(cellimage!)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
        //fatalError("init(coder:) has not been implemented")
    }
}
