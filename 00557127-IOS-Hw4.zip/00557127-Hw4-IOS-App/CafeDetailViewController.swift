//
//  CafeDetailViewController.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/19.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit
import Charts
import SafariServices

class CafeDetailViewController: UIViewController {

    @IBOutlet weak var scoreView: BarChartView!
    
    @IBOutlet weak var googleMaps: UIButton!
    @IBOutlet weak var fansPage: UIButton!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var storeName: UILabel!
    @IBOutlet weak var openTime: UILabel!
    var chartValue = [Double]()
    let valueLabel = ["wifi","seat","quiet","tasty","cheap","music"]
    
    var cafe : Cafe?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let cafe = cafe{
            storeName.text = cafe.name
            chartValue.append(cafe.wifi)
            chartValue.append(cafe.seat)
            chartValue.append(cafe.quiet)
            chartValue.append(cafe.tasty)
            chartValue.append(cafe.cheap)
            chartValue.append(cafe.music)
            initDetail()
        }
        setChart(dataLabel: valueLabel, values: chartValue)
        // Do any additional setup after loading the view.
    }
    func initDetail(){
        address.text = cafe?.address
        if(!(cafe?.open_time.isEmpty)!){
            openTime.text = cafe?.open_time
        }
        if((cafe?.url.isEmpty)! || cafe?.url==nil){
            fansPage.isEnabled=false
        }
    }
    func setChart(dataLabel: [String],values: [Double]){
        scoreView.noDataText = "No Data"
        
        var dataEntries = [BarChartDataEntry]()
        for i in 0...(dataLabel.count-1){
            let dataEntry = BarChartDataEntry(x: Double(i), y:values[i])
            dataEntries.append(dataEntry)
        }
        let dataSet = BarChartDataSet(entries: dataEntries, label: "Score")
        let chartData = BarChartData(dataSet: dataSet)
        dataSet.colors = [UIColor(red: 0.7, green: 0.3, blue: 0.7, alpha: 0.5)]
        scoreView.xAxis.labelPosition = .bottom
        scoreView.data = chartData
        scoreView.xAxis.valueFormatter = IndexAxisValueFormatter(values: dataLabel)
        scoreView.animate(xAxisDuration: 2.0,yAxisDuration: 2.0)
    }
    
    
    @IBAction func clickFansPage(_ sender: Any) {
        if let cafe = cafe{
            if let url = URL(string: cafe.url){
                let controller = SFSafariViewController(url: url)
                present(controller,animated: true)
            }
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let controller = segue.destination as? GoogleMapViewController{
            if let cafe = cafe{
                controller.lat = (cafe.latitude as NSString).doubleValue
                controller.lng = (cafe.longitude as NSString).doubleValue
                controller.name = cafe.name
            }
            
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
