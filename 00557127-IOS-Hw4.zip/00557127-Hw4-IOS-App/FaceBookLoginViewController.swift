//
//  FaceBookLoginViewController.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/19.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit
//import FBSDKLoginKit
//import FacebookCore
//import FacebookLogin

class FaceBookLoginViewController: UIViewController {
    /*@IBOutlet weak var loginButton: FBLoginButton!
    func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
    }
    
    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
    }
    
    func getData(){
        print("get")
    }

    @IBAction func login(_ sender: Any) {
/*let loginManager = LoginManager()
        loginManager.logIn(permissions: [.publicProfile,.email,.userFriends], viewController: self){
            (result)in
            switch (result){
            case .failed(let error):
                print(error)
            case .cancelled:
                print("cancel login")
            case .success(let granted, let declined, let token):
                print("user log in")
                self.getData()
            }
            
        }*/
        let loginManager = LoginManager()
        loginManager.logIn(permissions: [.publicProfile,.email,.userFriends], viewController: self) { (loginResult) in
            print(loginResult)
            switch loginResult{
            case .failed(let error): break
                //print(error)
            //失敗的時候回傳
            case .cancelled:
                print("the user cancels login")
            //取消時回傳內容
            case .success(let granted, let declined, let token):
                self.getData()
                print("user log in")
                //成功時print("user log in")
            }
        }
    }*/
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
