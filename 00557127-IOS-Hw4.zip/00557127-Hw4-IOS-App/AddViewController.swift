//
//  AddViewController.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/25.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit
import Kingfisher
//import FirebaseStorage

class AddViewController: UIViewController ,UIImagePickerControllerDelegate,UINavigationControllerDelegate{

    @IBOutlet weak var text: UITextView!
    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var sendButton: UIButton!
    @IBOutlet weak var imageChoose: UIImageView!
    //let imagePicker = UIImagePickerController()
    var url : URL = URL(string: "https://img.angelala.tw/20190209202533_56.jpg")!
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.imagePicker.delegate=self
        sendButton.layer.masksToBounds = true
        sendButton.layer.cornerRadius =
            sendButton.frame.width/2
        imageChoose.kf.setImage(with: url)
        //let imageTouch = UITapGestureRecognizer(target: self, action: #selector(imageChooseTouch))
        //imageChoose.isUserInteractionEnabled = true
        //self.imageChoose.addGestureRecognizer(imageTouch)
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func chooseDifferent(_ sender: Any) {
        switch segment.selectedSegmentIndex {
        case 0:
            url = URL(string: "https://img.angelala.tw/20190209202533_56.jpg")!
            break
        case 1:
            url = URL(string: "https://lh3.googleusercontent.com/M-V2pHkdISAFom_eiozW0bS1BIgJt4k5Z97neYL5ZyTJnc9P8IIkmGYg5Bos3Sgg2FLdCH35fL3rVHSQ3kkOmbYdG2-GsyqjuU4nGa765rOwRRdIfjsgvMUftWSerO4P9XoveC0uoCopO13rU5O5Qk2lMZMnfaluxAdV5gtDjwbWbXfmv4HZJHV_ghkuQUc4_JrWFC2BeIIyYvR0lz_DQ2KfqQ-IfoXxQEGO2SYyRz021Wd47EJhXA7V10M3hoIts2Bb_y1qyVHoxXEzU6EPy1JfHRrQ2jd_4TwdVOKLSl-jaLngqZ3VTJUoY7rndTPQK7Zqu1G6YNtNIYpmXCSHUy7VW-_-fJrfIvklXoq9wbmD0WOrwVUo82_aRwqd5XWtIGd2tyT1QBwPKrO-Oudv5s_LPJBGJoP1fQZ5yZo9btKgKV8CPlTtg2ZkawDqXpBLipAKj0qqROvDWSdrilBvv4faAEwmUIgohpm9X_hKcC73_UrJb90Cr3StM7Hvyjvs5FI8jgOSY-NZusWtcjEq4azGv4GbO6B8rs-HDa3hzKNB8U3gIPYZ11CGneM0JdMQ7GqPd8reofnAa0ScVAiAdvp6Fu-TleTtMT92RWqmfg=w1379-h919-no")!
            break
        case 2:
            url = URL(string: "https://pic.pimg.tw/peter2410/1540958141-3775685159_n.jpg")!
            break
        default:
            url = URL(string: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAqCbJB6S8vWG4hoqOWKqTu896qJybPpV4hknrMoMuXmH_7nm_")!
            break
        }
        self.imageChoose?.kf.indicatorType = .activity
        self.imageChoose.kf.setImage(with: url)
    }
    
    /*@objc func imageChooseTouch(){
        let controller = UIAlertController(title: "ImagePick", message: "選擇照片上傳", preferredStyle: .actionSheet)
        let albumAction = UIAlertAction(title: "相簿選取", style: .default,handler: {(action) in
            self.imagePicker.sourceType = .photoLibrary
            self.imagePicker.allowsEditing = true
            self.present(self.imagePicker,animated: true)
        })
        let cameraAction = UIAlertAction(title: "照相", style: .default,handler:nil)
        let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        controller.addAction(albumAction)
        controller.addAction(cameraAction)
        controller.addAction(cancelAction)
        present(controller, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]){
        imagePicker.dismiss(animated: true, completion: {
            if let image = info[.originalImage] as? UIImage{
                self.imageChoose.image = image
            }
            
            }
        )
        //imagePicker.dismiss(animated: true, completion: nil)
    }*/

    @IBAction func sendBtn(_ sender: Any) {
        let addRecord = Record(id: NSUUID().uuidString, url: url, description: text.text)
        RecordController.shared.post(record: addRecord)
        

        /*let uniqueString = NSUUID().uuidString
        if let selectedImage = self.imageChoose.image{
            print("-----\(selectedImage)")
            let storageRef = Storage.storage().reference().child("AppCodaFireUpload").child("\(uniqueString).png")
            if let uploadData = selectedImage.pngData(){
                storageRef.putData(uploadData, metadata: nil, completion: {(data,error) in
                    print("YYYYYY")
                    if error != nil{
                        print("ERRORRRRRR: \(error!.localizedDescription)")
                    }
                    else{
                        print("yeyeye")
                        
                    }
                    /*if let uploadImgURL = data?.downloadURL()?.absoluteString{
                     print("PhotoURL: \(uploadImgURL)")*/
                })
            }
        }*/
        /*let fileManager = FileManager.default
        let docURLs = fileManager.urls(for: .documentDirectory, in: .userDomainMask)
        let docURL=docURLs.first
        /*let url = docURL?.appendingPathComponent("photoArrat.txt")*/
        let interval = Date.timeIntervalSinceReferenceDate
        let name = "\(interval).jpg"*/
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
