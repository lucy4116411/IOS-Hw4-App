//
//  Record.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/25.
//  Copyright © 2019 alulu. All rights reserved.
//

import Foundation

struct Record : Codable{
    internal var id: String
    internal var url: URL
    internal var description: String
}
struct RecordData: Encodable{
    var data:Record
}
class RecordController{
    let sheetDBAPI = "https://sheetdb.io/api/v1/diogbl0jdu7zy"
    var records = [Record]()
    static let shared = RecordController()
    
    func post(record: Record){
        let url = URL(string: self.sheetDBAPI)
        var urlRequest = URLRequest(url: url!)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let recordData = RecordData(data: record)
        let jsonEncoder = JSONEncoder()
        if let data = try? jsonEncoder.encode(recordData){
            let task = URLSession.shared.uploadTask(with: urlRequest, from: data){(rdata,response,error) in
                if (error != nil){
                    print(error)
                }
            }
            task.resume()
        }else{
            print("Post failed!!!!!!!!!!!!!!!!!")
        }
    }
    
    func getAllRecord() -> [Record]{
        if let url = URL(string: self.sheetDBAPI){
            let task = URLSession.shared.dataTask(with: url){(data,response,error) in
                if let data = data{
                    do{
                        let recordList = try JSONDecoder().decode(Array<Record>.self, from: data)
                        for rec in recordList{
                            self.records.append(rec)
                        }
                    }
                    catch{
                        print(error)
                    }
                }
            }
            task.resume()
        }
        else{
            print("get Failed")
        }
        return records
    }
}
