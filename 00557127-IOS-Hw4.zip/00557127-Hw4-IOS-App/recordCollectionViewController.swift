//
//  recordCollectionViewController.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/19.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit

class recordCollectionViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    @IBOutlet var des: UITextView!
    @IBOutlet weak var photoCollectionViewLayout: UICollectionViewFlowLayout!
    @IBOutlet weak var photoCollectionViewControl: UICollectionView!
    @IBOutlet weak var selfPhoto: UIImageView!
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var plus: UIButton!
    @IBOutlet weak var edit: UIButton!
    let imagePicker = UIImagePickerController()
    var records:[Record] = [Record]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initDisplay()
        self.imagePicker.delegate=self
        //fetchAllData()
        // Do any additional setup after loading the view.
    }
    
    func fetchAllData(){
        //https://sheetdb.io/api/v1/diogbl0jdu7zy
        let urlS = "https://sheetdb.io/api/v1/diogbl0jdu7zy"
        if let url = URL(string: urlS){
            let task = URLSession.shared.dataTask(with: url){(data,res,error) in
                if let data = data{
                    do{
                        let recList = try JSONDecoder().decode(Array<Record>.self,from:data)
                        for rec in recList{
                            self.records.append(rec)
                        }
                        DispatchQueue.main.async {
                            self.collectionView.reloadData()
                        }
                    }catch{
                        print(error)
                    }
                }
            }
            task.resume()
        }
    }
    func initDisplay(){
        plus.layer.masksToBounds = true
        plus.layer.cornerRadius = plus.frame.width/2
        edit.layer.masksToBounds = true
        edit.layer.cornerRadius = edit.frame.width/2
        
        photoCollectionViewLayout.sectionInset = UIEdgeInsets(top: 1, left: 1, bottom: 1, right: 1)
        photoCollectionViewLayout.itemSize = CGSize(width: ((UIScreen.main.bounds.size.width/3)-10), height: collectionView.frame.height/3)
        photoCollectionViewLayout.minimumLineSpacing = 5
        photoCollectionViewLayout.scrollDirection = .vertical
        //photoCollectionViewLayout.headerReferenceSize = CGSize(width: UIScreen.main.bounds.size.width, height: 40)
    }
    
    @IBAction func editBtn(_ sender: Any) {
        let controller = UIAlertController(title: "ImagePick", message: "選擇照片上傳", preferredStyle: .actionSheet)
        let albumAction = UIAlertAction(title: "相簿選取", style: .default,handler: {(action) in
            self.imagePicker.sourceType = .photoLibrary
            self.imagePicker.allowsEditing = true
            self.present(self.imagePicker,animated: true)
        })
        let cameraAction = UIAlertAction(title: "照相", style: .default,handler:nil)
        let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        controller.addAction(albumAction)
        controller.addAction(cameraAction)
        controller.addAction(cancelAction)
        present(controller, animated: true, completion: nil)
    }
    @IBAction func plusAction(_ sender: Any) {
       /* let controller = UIAlertController(title: "ImagePick", message: "選擇照片上傳", preferredStyle: .actionSheet)
        let albumAction = UIAlertAction(title: "相簿選取", style: .default,handler: {(action) in
               self.imagePicker.sourceType = .photoLibrary
               self.imagePicker.allowsEditing = true
            self.present(self.imagePicker,animated: true)
            })
        let cameraAction = UIAlertAction(title: "照相", style: .default,handler:nil)
        let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        controller.addAction(albumAction)
        controller.addAction(cameraAction)
        controller.addAction(cancelAction)
        present(controller, animated: true, completion: nil)*/
    }
    
   func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]){
        let image = info[.originalImage] as? UIImage
    self.selfPhoto.image = image!.crop(ratio:1.0)
        imagePicker.dismiss(animated: true, completion: nil)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return records.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "photoCell", for: indexPath) as! imageCollectionViewCell
        /*if let image = UIImage(named: "test"){
            print("find photo")
            cell.cellimage?.image = image
            
        }*/
        
        cell.image?.kf.indicatorType = .activity
        cell.image.kf.setImage(with: records[indexPath.row].url)
        /*let tmp = UIImage(named: "test")?.crop(ratio: 1.0)
        cell.image?.image = tmp*/
        return cell
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        des.text = records[indexPath.row].description
    }
    
    func collectionView(collectionView: UICollectionView,layout collectionViewLayout: UICollectionViewLayout,sizeForItemAtIndexPath indexPath: NSIndexPath)->CGSize{
        let minSpace:CGFloat = 10.0
        return CGSize(width: (collectionView.frame.width-minSpace)/3,height: 100)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        records = [Record]()
        fetchAllData()
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UIImage{
    func crop(ratio: CGFloat)->UIImage{
        var newSize:CGSize!
        if ((size.width/size.height) > ratio){
            newSize = CGSize(width: size.height*ratio, height: size.height)
        }
        else{
            newSize = CGSize(width: size.width, height: size.width*ratio)
        }
        var rect = CGRect.zero
        rect.size.width = size.width
        rect.size.height = size.height
        rect.origin.x = (newSize.width-size.width)/2.0
        rect.origin.y = (newSize.height-size.height)/2.0
        
        UIGraphicsBeginImageContext(newSize)
        draw(in: rect)
        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return scaledImage!
    }
}
