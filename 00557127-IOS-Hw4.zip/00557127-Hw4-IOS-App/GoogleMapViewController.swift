//
//  GoogleMapViewController.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/19.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit
import GoogleMaps

class GoogleMapViewController: UIViewController {

    @IBOutlet weak var googleMapView: GMSMapView!
    var lat : CLLocationDegrees?
    var lng : CLLocationDegrees?
    var name : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let lat = lat, let lng = lng, let name = name{
            let camera = GMSCameraPosition.camera(withLatitude: lat, longitude: lng, zoom: 18.0)
            googleMapView.camera = camera
            
            let marker = GMSMarker()
            marker.position = CLLocationCoordinate2D(latitude: lat, longitude: lng)
            marker.title = "Here!"
            marker.snippet = name
            marker.map = googleMapView
            
        }
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
