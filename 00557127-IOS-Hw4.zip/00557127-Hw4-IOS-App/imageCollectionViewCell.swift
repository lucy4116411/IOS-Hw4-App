//
//  imageCollectionViewCell.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/19.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit

class imageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
}
