//
//  Cafe.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/12.
//  Copyright © 2019 alulu. All rights reserved.
//


import Foundation

internal struct Cafe : Codable{
    internal var id: String
    internal var name: String
    internal var wifi: Double
    internal var seat: Double
    internal var quiet: Double
    internal var tasty: Double
    internal var cheap: Double
    internal var music: Double
    internal var url: String
    internal var address: String
    internal var latitude: String
    internal var longitude: String
    internal var limited_time: String
    internal var socket: String
    internal var standing_desk: String
    internal var mrt: String
    internal var open_time: String
    
}

internal struct CafeList : Codable{
    internal var list : [Cafe]
}
