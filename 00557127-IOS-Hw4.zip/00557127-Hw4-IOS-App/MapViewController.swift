//
//  MapViewController.swift
//  00557127-Hw4-IOS-App
//
//  Created by user on 2019/6/12.
//  Copyright © 2019 alulu. All rights reserved.
//

import UIKit

class MapViewController: UIViewController {

    @IBOutlet weak var keelung: UIButton!
    @IBOutlet weak var taipei: UIButton!
    @IBOutlet weak var taoyuan: UIButton!
    @IBOutlet weak var hsinchu: UIButton!
    @IBOutlet weak var miaoli: UIButton!
    @IBOutlet weak var taichung: UIButton!
    @IBOutlet weak var changhua: UIButton!
    @IBOutlet weak var nantou: UIButton!
    @IBOutlet weak var yunlin: UIButton!
    @IBOutlet weak var chiayi: UIButton!
    @IBOutlet weak var tainan: UIButton!
    @IBOutlet weak var kaohsiung: UIButton!
    @IBOutlet weak var pingtung: UIButton!
    @IBOutlet weak var taitung: UIButton!
    @IBOutlet weak var hualien: UIButton!
    @IBOutlet weak var yilan: UIButton!
    @IBOutlet weak var lienchiang: UIButton!
    @IBOutlet weak var penghu: UIButton!
    
    func initButton(){
        keelung.layer.masksToBounds = true
        keelung.layer.cornerRadius = keelung.frame.width/2
        taipei.layer.masksToBounds = true
        taipei.layer.cornerRadius = taipei.frame.width/2
        taoyuan.layer.masksToBounds = true
        taoyuan.layer.cornerRadius = taoyuan.frame.width/2
        hsinchu.layer.masksToBounds = true
        hsinchu.layer.cornerRadius = hsinchu.frame.width/2
        miaoli.layer.masksToBounds = true
        miaoli.layer.cornerRadius = miaoli.frame.width/2
        taichung.layer.masksToBounds = true
        taichung.layer.cornerRadius = taichung.frame.width/2
        changhua.layer.masksToBounds = true
        changhua.layer.cornerRadius = changhua.frame.width/2
        nantou.layer.masksToBounds = true
        nantou.layer.cornerRadius = nantou.frame.width/2
        yunlin.layer.masksToBounds = true
        yunlin.layer.cornerRadius = yunlin.frame.width/2
        chiayi.layer.masksToBounds = true
        chiayi.layer.cornerRadius = chiayi.frame.width/2
        tainan.layer.masksToBounds = true
        tainan.layer.cornerRadius = tainan.frame.width/2
        kaohsiung.layer.masksToBounds = true
        kaohsiung.layer.cornerRadius = kaohsiung.frame.width/2
        pingtung.layer.masksToBounds = true
        pingtung.layer.cornerRadius = pingtung.frame.width/2
        taitung.layer.masksToBounds = true
        taitung.layer.cornerRadius = taitung.frame.width/2
        hualien.layer.masksToBounds = true
        hualien.layer.cornerRadius = hualien.frame.width/2
        yilan.layer.masksToBounds = true
        yilan.layer.cornerRadius = yilan.frame.width/2
        lienchiang.layer.masksToBounds = true
        lienchiang.layer.cornerRadius = lienchiang.frame.width/2
        penghu.layer.masksToBounds = true
        penghu.layer.cornerRadius = penghu.frame.width/2
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        initButton()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let controller = segue.destination as? CafeTableViewController
        
        controller?.search = segue.identifier
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
